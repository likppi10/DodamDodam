package com.ssafy.family.data.remote.url

object Url {
    const val BASE_URL = "https://happydodam.com"
}